ConvertDatabaseCharset Extra
==========================================

**Author:** Bob Ray [Bob's Guides](https://bobsguides.com)

**Documentation:** [ConverDatabaseCharset Docs](https://bobsguides.com/convert-db-utf8.html)

**Bugs and requests:** [ConvertDatabaseCharset Issues](https://github.com/BobRay/ConverDatabaseCharset/issues)

**Questions about using ConvertDatabaseCharset** [MODX Forums](https://forums.modx.com)


ConvertDatabaseCharset is a utility to safely convert a database from one character set to another (e.g., Latin1 -> utf-8).



