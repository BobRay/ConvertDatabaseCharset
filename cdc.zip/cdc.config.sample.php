<?php

/* set these to match your database credentials */


$host = 'localhost';
$dbName = 'YourDbName';
$userName = 'YourDbUserName';
$password = 'YourDbPassword';
$convertNewlines = false; /* convert \n to <br /> in output - use if you will run this in a browser */
$targetCharset = 'utf8';
$targetCollation = 'utf8_general_ci';
$showHeaders = true; /* Show the header text */
$cdc_debug = 0; /* show debugging information */
$showSql = true;

