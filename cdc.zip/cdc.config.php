<?php

/* set these to match your database credentials */

$showHeaders = false; 
$host = 'localhost';
$dbName = 'johnflaa_modx31';
$userName = 'BobRay';
$password = 'Mutant0';
$convertNewlines = false;
$targetCharset = 'utf8';
$targetCollation = 'utf8_general_ci';
//$targetCharset = 'latin1';
//$targetCollation = 'latin1_swedish_ci';

$cdc_debug = false;
$showSql = true;

return '';